using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Win11
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll")]
        public static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vlc);
        [DllImport("user32.dll")]
        public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        Button btnKey;
        Button btnHide;
        Button btnReset;
        bool isWaitingForKey = false;
        private NotifyIcon trayIcon;
        private string configPath = "config.txt";
        private string savePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Screenshots");
        private int currentHotKey = (int)Keys.PrintScreen;

        public Form1()
        {
            InitializeComponent();
            LoadSettings(); 
            SetupTray();
            SetupUI();
            RegisterGlobalHotKey();
        }

        private void LoadSettings()
        {
            if (File.Exists(configPath))
            {
                int.TryParse(File.ReadAllText(configPath), out currentHotKey);
            }
        }

        private void SaveSettings()
        {
            File.WriteAllText(configPath, currentHotKey.ToString());
        }

        private void SetupTray()
        {
            var trayMenu = new ContextMenuStrip();
            trayMenu.Items.Add("Settings", null, (s, e) => { this.Show(); this.WindowState = FormWindowState.Normal; });
            trayMenu.Items.Add("Exit", null, (s, e) => { UnregisterHotKey(this.Handle, 1); Application.ExitThread(); });
            Icon customIcon = new Icon("my_icon.ico");
            trayIcon = new NotifyIcon()
            {
                Icon = customIcon,
                ContextMenuStrip = trayMenu,
                Visible = true,
                Text = "Screenshot active"
            };
        }

        private void SetupUI()
        {
            this.Text = "Setting screenshot";
            this.Size = new Size(350, 250);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.ForeColor = Color.White;

            btnKey = new Button
            {
                Text = $"Key: {(Keys)currentHotKey}",
                Location = new Point(20, 60),
                Size = new Size(180, 40),
                FlatStyle = FlatStyle.Flat
            };
            btnHide = new Button
            {
                Text = "Close",
                Location = new Point(200, 160),
                Size = new Size(100, 35),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.DarkSlateGray
            };
            btnReset = new Button
            {
                Text = "Reset to PrintScreen",
                Location = new Point(20, 110), 
                Size = new Size(180, 30),
                FlatStyle = FlatStyle.Flat
            };

            btnReset.Click += (s, e) => {
                UnregisterHotKey(this.Handle, 1);
                currentHotKey = 0x2C;
                RegisterGlobalHotKey();
                SaveSettings();
                btnKey.Text = "Key: PrintScreen";
                MessageBox.Show("Settings are reseted to Print Screen!");
            };
            this.Controls.Add(btnReset);
            btnHide.Click += (s, e) => this.Hide();

            this.Controls.Add(btnKey);
            this.Controls.Add(btnHide);
            isWaitingForKey = false; 

            btnKey.Click += (s, e) =>
            {
                btnKey.Text = "Press key...";
                isWaitingForKey = true;
                this.Focus(); 
            };
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (isWaitingForKey)
            {
                UnregisterHotKey(this.Handle, 1);
                currentHotKey = (int)keyData;
                RegisterGlobalHotKey();
                SaveSettings();
                btnKey.Text = $"Key: {keyData}";
                isWaitingForKey = false;

                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }


        private void RegisterGlobalHotKey()
        {
            bool success = RegisterHotKey(this.Handle, 1, 0, currentHotKey);
            if (!success) MessageBox.Show("Unable to occupy this key! It may be in use by the system..");
        }

        private void CaptureScreen()
        {
            try
            {
                if (!Directory.Exists(savePath)) Directory.CreateDirectory(savePath);
                string filePath = Path.Combine(savePath, $"Snap_{DateTime.Now:yyyyMMdd_HHmmss}.png");

                Rectangle bounds = Screen.PrimaryScreen.Bounds;
                using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height))
                {
                    using (Graphics g = Graphics.FromImage(bitmap))
                        g.CopyFromScreen(Point.Empty, Point.Empty, bounds.Size);
                    bitmap.Save(filePath, ImageFormat.Png);
                    Clipboard.SetImage(bitmap);
                }
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "powershell",
                    Arguments = $"-Command \"Start-Process 'ms-screenclip:edit?source={filePath}'\"",
                    CreateNoWindow = true,
                    WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
                });
            }
            catch (Exception ex) { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                this.Hide();
            }
            base.OnFormClosing(e);
        }

        protected override void SetVisibleCore(bool value)
        {
            if (!this.IsHandleCreated) { CreateHandle(); value = false; }
            base.SetVisibleCore(value);
        }
        protected override void WndProc(ref Message m)
        {
            const int WM_KEYDOWN = 0x0100;
            const int WM_SYSKEYDOWN = 0x0104;
            const int WM_HOTKEY = 0x0312;
            if (isWaitingForKey && (m.Msg == WM_KEYDOWN || m.Msg == WM_SYSKEYDOWN))
            {
                int pressedKey = (int)m.WParam;
                if (pressedKey != currentHotKey || pressedKey == 0x2C)
                {
                    UnregisterHotKey(this.Handle, 1); 

                    if (RegisterHotKey(this.Handle, 1, 0, pressedKey))
                    {
                        currentHotKey = pressedKey;
                        SaveSettings();
                        btnKey.Text = $"Клавиша: {(Keys)currentHotKey}";
                        isWaitingForKey = false;
                    }
                    else
                    {
                        MessageBox.Show("Эта клавиша занята системой или другой программой!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        RegisterHotKey(this.Handle, 1, 0, currentHotKey);
                        btnKey.Text = $"Клавиша: {(Keys)currentHotKey}";
                        isWaitingForKey = false;
                    }
                }
                else
                {
                    btnKey.Text = $"Клавиша: {(Keys)currentHotKey}";
                    isWaitingForKey = false;
                }
            }
            if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == 1)
            {
                CaptureScreen();
            }

            base.WndProc(ref m);
        }
    }
}

