using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Win11
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll")]
        public static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vlc);
        [DllImport("user32.dll")]
        public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        private NotifyIcon trayIcon;
        private string configPath = "config.txt";
        private string savePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Screenshots");
        private int currentHotKey = (int)Keys.PrintScreen;

        public Form1()
        {
            InitializeComponent();
            LoadSettings(); 
            SetupTray();
            SetupUI();
            RegisterGlobalHotKey();
        }

        private void LoadSettings()
        {
            if (File.Exists(configPath))
            {
                int.TryParse(File.ReadAllText(configPath), out currentHotKey);
            }
        }

        private void SaveSettings()
        {
            File.WriteAllText(configPath, currentHotKey.ToString());
        }

        private void SetupTray()
        {
            var trayMenu = new ContextMenuStrip();
            trayMenu.Items.Add("Настройки", null, (s, e) => { this.Show(); this.WindowState = FormWindowState.Normal; });
            trayMenu.Items.Add("Выход", null, (s, e) => { UnregisterHotKey(this.Handle, 1); Application.ExitThread(); });

            trayIcon = new NotifyIcon()
            {
                Icon = SystemIcons.Information,
                ContextMenuStrip = trayMenu,
                Visible = true,
                Text = "Скриншотер активен"
            };
        }

        private void SetupUI()
        {
            this.Text = "Настройки скриншотера";
            this.Size = new Size(350, 250);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.ForeColor = Color.White;

            Button btnKey = new Button
            {
                Text = $"Клавиша: {(Keys)currentHotKey}",
                Location = new Point(20, 60),
                Size = new Size(180, 40),
                FlatStyle = FlatStyle.Flat
            };

            btnKey.Click += (s, e) => {
                btnKey.Text = "Нажми клавишу...";
                btnKey.BackColor = Color.FromArgb(60, 60, 60); 
                this.KeyPreview = true;
                KeyEventHandler tempHandler = null;
                tempHandler = (sender, args) => {
                    int newKey = (int)args.KeyCode;
                    bool success = RegisterHotKey(this.Handle, 2, 0, newKey);

                    if (success)
                    {
                        UnregisterHotKey(this.Handle, 1);
                        UnregisterHotKey(this.Handle, 2);
                        currentHotKey = newKey;
                        RegisterHotKey(this.Handle, 1, 0, currentHotKey);
                        SaveSettings();

                        btnKey.Text = $"Клавиша: {args.KeyCode}";
                        btnKey.BackColor = Color.FromArgb(45, 45, 45);
                    }
                    else
                    {
                        MessageBox.Show($"Клавиша {args.KeyCode} заблокирована системой или другой программой!",
                                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        btnKey.Text = $"Клавиша: {(Keys)currentHotKey}";
                        btnKey.BackColor = Color.FromArgb(45, 45, 45);
                    }
                    this.KeyDown -= tempHandler;
                    this.KeyPreview = false;
                };

                this.KeyDown += tempHandler;
            };

            Button btnHide = new Button
            {
                Text = "Скрыть",
                Location = new Point(200, 160),
                Size = new Size(100, 35),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.DarkSlateGray
            };
            btnHide.Click += (s, e) => this.Hide();

            this.Controls.Add(btnKey);
            this.Controls.Add(btnHide);
        }

        private void RegisterGlobalHotKey()
        {
            bool success = RegisterHotKey(this.Handle, 1, 0, currentHotKey);
            if (!success) MessageBox.Show("Не удалось занять эту клавишу! Возможно, она используется системой.");
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0312 && m.WParam.ToInt32() == 1)
            {
                CaptureScreen();
            }
            base.WndProc(ref m);
        }

        private void CaptureScreen()
        {
            try
            {
                if (!Directory.Exists(savePath)) Directory.CreateDirectory(savePath);
                string filePath = Path.Combine(savePath, $"Snap_{DateTime.Now:yyyyMMdd_HHmmss}.png");

                Rectangle bounds = Screen.PrimaryScreen.Bounds;
                using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height))
                {
                    using (Graphics g = Graphics.FromImage(bitmap))
                        g.CopyFromScreen(Point.Empty, Point.Empty, bounds.Size);
                    bitmap.Save(filePath, ImageFormat.Png);
                    Clipboard.SetImage(bitmap);
                }
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "powershell",
                    Arguments = $"-Command \"Start-Process 'ms-screenclip:edit?source={filePath}'\"",
                    CreateNoWindow = true,
                    WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
                });
            }
            catch (Exception ex) { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                this.Hide();
            }
            base.OnFormClosing(e);
        }

        protected override void SetVisibleCore(bool value)
        {
            if (!this.IsHandleCreated) { CreateHandle(); value = false; }
            base.SetVisibleCore(value);
        }
    }
}

